#include "impl.h"
#include<stdio.h>
void sameBST(struct BST*t1,struct BST*t2)
{
	int n1=0,n2=0,arr1[100],arr2[100];
	inorderModify(t1,arr1,&n1);
	inorderModify(t2,arr2,&n2);
	if(n1!=n2)
		printf("Not same\n");
	else
	{
		for(int i=0;i<n1;i++)
		{
			if(arr1[i]!=arr2[i])
			{
				printf("Not same\n");
				return;
			}
			
		}
	}
}		

int main()
{
	struct BST *t=NULL,*p=NULL;
	t=insert(t,29);
	insert(t,23);
	insert(t,4);
	insert(t,13);
	insert(t,39);
	insert(t,31);
	insert(t,45);
	insert(t,56);
	insert(t,49);
	p=insert(p,29);
	insert(p,23);
	insert(p,4);
	insert(p,13);
	insert(p,39);
	insert(p,31);
	insert(p,45);
	insert(p,56);
	insert(p,49);
	sameBST(t,p);
}
